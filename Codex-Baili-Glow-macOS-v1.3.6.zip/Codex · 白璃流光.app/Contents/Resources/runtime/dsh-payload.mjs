import { readFile } from 'node:fs/promises';
import { join } from 'node:path';

export async function buildDshPayload(root) {
  const [react, upstream, adapter, petData] = await Promise.all(
    ['react.js', 'upstream.js', 'adapter.js', 'baili-pets.json'].map(file => readFile(join(root, 'dsh', file), 'utf8'))
  );
  return `(() => {
    try {
      if (window.__bailiDsh) return { installed: true };
      ${react}
      const bailiPetAssets = ${JSON.stringify(JSON.parse(petData))};
      let dsh;
      function registerBailiDsh({ factory }) {
        dsh = factory(name => {
          if (name === 'react') return BailiDshReact.React;
          throw new Error('DSH host module unavailable: ' + name);
        });
      }
      ${upstream}
      ${adapter}
      return installDshCodex(BailiDshReact, dsh);
    } catch (error) {
      window.__bailiDsh?.dispose();
      console.error('[Baili Glow] Failed to mount', error);
      return { installed: false, reason: error.message };
    }
  })()`;
}
