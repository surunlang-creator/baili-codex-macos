// Codex host adapter. DSH visual assets and settings live in upstream.js.
function installDshCodex({ React, createRoot }, dsh) {
  window.__bailiDsh?.dispose();
  const h = React.createElement;
  const { configStore, ClaudeEffortPopover, ClaudeSettingsPage, QuickDrawer, useResolvedTheme } = dsh;
  const HOST = '[data-codex-composer-root]';
  const SURFACE = '[data-composer-surface-variant]';
  const EDITOR = '[data-composer-markdown],[contenteditable="true"][role="textbox"],.ProseMirror[contenteditable="true"]';
  const TRIGGER = '[data-composer-navigation-target="reasoning"][data-selected-reasoning-effort]';
  const modelAnchor = trigger => trigger?.parentElement?.tagName === 'SPAN' ? trigger.parentElement : trigger;
  const STOP = /^(?:Stop(?: generation)?|停止(?:生成|回答|响应)?|停止產生|停止生成回覆)$/i;
  const config = configStore.getSnapshot;
  const recognizedEfforts = ['none', 'off', 'minimal', 'low', 'medium', 'high', 'xhigh', 'max', 'ultra'];
  const names = { none:'无', off:'关闭', minimal:'最低', low:'轻度', medium:'中', high:'高', xhigh:'极高', max:'最高', ultra:'Ultra' };
  // Match the native picker contract, with no guesses about available levels or model IDs.
  function picker(composer) {
    const button = composer?.querySelector(TRIGGER);
    if (!button || button.matches(':disabled,[aria-disabled="true"]')) return null;
    const key = Object.getOwnPropertyNames(button).find(key => key.startsWith('__reactFiber$'));
    // The native picker owns the trigger through multiple Radix and React wrappers.
    for (let fiber = key && button[key], depth = 0; fiber && depth < 96; fiber = fiber.return, depth++) {
      for (const props of [fiber.memoizedProps, fiber.alternate?.memoizedProps]) {
        const current = props?.selectedPowerSelection;
        if (!current || !Array.isArray(props.powerSelections) || typeof props.onSelectPower !== 'function' ||
            props.disabled || props.powerSelectionDisabled || current.isLocked ||
            current.reasoningEffort !== button.dataset.selectedReasoningEffort || typeof current.model !== 'string') continue;
        const displayedModel = button.querySelector('[data-model-selection-label]')?.dataset.modelSelectionLabel;
        if (displayedModel && displayedModel !== current.model) continue;
        const options = props.powerSelections.filter(option => option.model === current.model &&
          !option.isLocked && !option.disabled && !option.isRateLimited && !option.requiresExplicitSelection &&
          recognizedEfforts.includes(option.reasoningEffort))
          .sort((a, b) => recognizedEfforts.indexOf(a.reasoningEffort) - recognizedEfforts.indexOf(b.reasoningEffort))
          .filter((option, index, all) => all.findIndex(item => item.reasoningEffort === option.reasoningEffort) === index);
        if (!options.some(option => option.id === current.id) || new Set(options.map(option => option.reasoningEffort)).size < 2) continue;
        return { button, props, current, options };
      }
    }
    return null;
  }

  const style = document.createElement('style');
  style.dataset.plugin = 'baili-dsh';
  style.textContent = dsh.visualCss
    .replaceAll('[data-composer-seat] > *', '[data-baili-dsh-seat] > [data-baili-dsh-card]')
    .replaceAll('[data-composer-seat]', '[data-baili-dsh-seat]')
    .replaceAll('[data-composer-card]', '[data-baili-dsh-card]')
    .replaceAll('[data-composer-input]', '[data-baili-dsh-editor]') + `
  [data-baili-dsh-card],[data-baili-dsh-seat]{position:relative}
  [data-baili-dsh-card] > .dcs-prism-rim-cv{inset:0!important;width:100%!important;height:100%!important}
  :is([data-baili-dsh-seat],[data-baili-dsh-card]) > .dcs-pet-stage{z-index:12}
  .baili-dsh-inline-mount{display:flex;flex:0 1 auto;min-width:0;align-self:center;margin-inline-end:4px}
  .baili-dsh-inline-effort{position:relative;display:grid;gap:2px;width:clamp(132px,19vw,184px);min-width:0;padding:3px 5px 1px;box-sizing:border-box;border:1px solid color-mix(in srgb,var(--accent) 27%,transparent);border-radius:10px;background:color-mix(in srgb,var(--accent) 7%,var(--color-background-composer-surface,transparent));direction:ltr}
  .baili-dsh-inline-effort .dcs-track-container{height:18px;touch-action:none;cursor:ew-resize}
  .baili-dsh-inline-effort .dcs-thumb:not(.is-art){width:18px;height:18px}
  .baili-dsh-inline-effort .dcs-thumb:not(.is-art) .dcs-thumb-body{transform:scale(.72)}
  .baili-dsh-inline-effort .dcs-thumb-art{height:32px!important;width:auto!important;max-width:38px}
  .baili-dsh-inline-effort .dcs-tier-buttons{margin:0;display:grid;grid-auto-columns:minmax(0,1fr);grid-auto-flow:column;gap:1px}
  .baili-dsh-inline-effort .dcs-tier-btn{padding:1px 0;height:13px;font-weight:600;font-size:9px;line-height:11px;white-space:nowrap;color:var(--color-text-secondary,#564a69)}
  .baili-dsh-inline-effort .dcs-tier-btn.is-active{font-weight:750}
  .baili-dsh-inline-effort :focus-visible,.baili-dsh-panel button:focus-visible{outline:2px solid var(--accent,#a78bfa);outline-offset:2px}
  .baili-dsh-inline-effort .baili-dsh-effort-status{position:absolute;width:1px;height:1px;overflow:hidden;clip-path:inset(50%);pointer-events:none}
  .baili-dsh-panel{box-sizing:border-box;position:fixed;margin:auto;inset:0;width:min(490px,calc(100vw - 32px));max-height:calc(100dvh - 40px);padding:15px;border-radius:22px;overflow:auto;font:13px/1.45 system-ui;color:#201832;background:rgba(249,246,255,.94);border:1px solid #d7c6f6;box-shadow:0 20px 90px #28134e55}
  .baili-dsh-panel.is-dark{color:#f7f2ff;background:rgba(25,21,39,.96);border-color:#514269}
  .baili-dsh-panel::backdrop{background:#17112358}
  .baili-dsh-panel .baili-dsh-bar{display:flex;align-items:center;gap:6px;margin-bottom:10px}
  .baili-dsh-panel .baili-dsh-bar strong{margin-right:auto;font-size:14px}
  .baili-dsh-panel .baili-dsh-bar button{font:inherit;color:inherit;background:transparent;border:1px solid #9e85c066;border-radius:9px;padding:5px 9px;cursor:pointer}
  .baili-dsh-panel .baili-dsh-bar button[aria-pressed="true"]{background:#8b5cf62b}
  .baili-dsh-panel .dcs-settings-page{padding:0;max-width:none}
  .baili-dsh-panel .dcs-quick-drawer{max-height:min(54vh,440px)}
  @media (prefers-reduced-motion:reduce){.baili-dsh-panel *{animation:none!important;transition:none!important}}
  `;
  document.head.append(style);
  const cards = new Map();
  const panel = document.createElement('dialog');
  panel.className = 'baili-dsh-panel';
  panel.setAttribute('aria-label', '流光输入框设置');
  document.body.append(panel);
  const root = createRoot(panel);
  let active, timer = 0, disposed = false;
  const body = document.body;
  const unmountEffect = dsh.installComposerBeautifier({ get: () => undefined });

  const pendingSelections = new WeakSet();
  async function commitEffort(composer, modelName, effort) {
    const native = picker(composer);
    const selected = native?.options.find(option => option.reasoningEffort === effort);
    if (!selected || modelName !== native.current.model) return '当前模型档位已变化，请重新选档。';
    if (selected.id === native.current.id) return '';
    if (pendingSelections.has(composer)) return '正在切换档位…';
    pendingSelections.add(composer);
    try {
      await native.props.onSelectPower(selected);
      await native.props.onCommitPower?.(selected, native.current);
      for (let attempt = 0; attempt < 50 && composer.isConnected && !disposed; attempt++) {
        const confirmed = picker(composer)?.current;
        if (confirmed?.model === modelName && confirmed.reasoningEffort === effort) return '档位已更新';
        await new Promise(resolve => setTimeout(resolve, 50));
      }
      return 'Codex 未确认切换，请使用原生模型菜单。';
    } catch {
      return '档位切换失败，请使用原生模型菜单。';
    } finally {
      pendingSelections.delete(composer);
    }
  }

  function InlineEffort({ composer, native }) {
    const cfg = React.useSyncExternalStore(configStore.subscribe, config);
    const dark = useResolvedTheme(cfg.themeMode);
    const [busy, setBusy] = React.useState(false);
    const [status, setStatus] = React.useState('');
    const [revision, setRevision] = React.useState(0);
    const current = {provider:'codex', model:native.current.model, reasoningEffort:native.current.reasoningEffort};
    const reasoning = {efforts:native.options.map(option => ({id:option.reasoningEffort, name:names[option.reasoningEffort]}))};
    async function select({model, reasoningEffort}) {
      if (pendingSelections.has(composer)) return;
      setBusy(true);
      setStatus('正在切换档位…');
      const result = await commitEffort(composer, model, reasoningEffort);
      setStatus(result);
      setBusy(false);
      if (result !== '档位已更新') setRevision(id => id + 1);
      schedule();
    }
    return h(ClaudeEffortPopover, {key:revision, inline:true, current, reasoning, select, busy, dark, status,
      onClose:() => openSettings(composer)});
  }

  function SettingsPanel() {
    const cfg = React.useSyncExternalStore(configStore.subscribe, config);
    const dark = useResolvedTheme(cfg.themeMode);
    const [general, setGeneral] = React.useState(cfg.enabled === false);
    React.useLayoutEffect(() => { panel.classList.toggle('is-dark', dark); }, [dark]);
    return h('div', {className:dark ? 'dark' : 'light', style:{'--accent':cfg.accentColor,'--glass-opacity':cfg.glassOpacity}},
      h('header', {className:'baili-dsh-bar'}, h('strong', null, '流光外观设置'),
        h('button', {type:'button','aria-pressed':general,onClick:() => setGeneral(!general)}, general ? '动效与外观' : '常规'),
        h('button', {type:'button','aria-label':'关闭',onClick:() => panel.close()}, '×')),
      general ? h(ClaudeSettingsPage) : h(QuickDrawer, {config:cfg, dark, onClose:() => panel.close()}));
  }

  function openSettings(composer) {
    active = composer;
    if (!panel.open) panel.showModal();
    root.render(h(SettingsPanel));
  }
  panel.addEventListener('close', () => { if (!disposed && !panel.open) { active = null; root.render(null); } });
  panel.addEventListener('click', event => {
    if (event.target === panel) {
      const rect = panel.getBoundingClientRect();
      if (event.clientX < rect.left || event.clientX > rect.right || event.clientY < rect.top || event.clientY > rect.bottom) panel.close();
    }
  });

  function clear(item) {
    item.sliderRoot.unmount();
    item.sliderMount.remove();
    item.editor.removeAttribute('data-baili-dsh-editor');
    item.card.removeAttribute('data-baili-dsh-card');
    item.seat.removeAttribute('data-baili-dsh-seat');
    item.card.removeAttribute('data-baili-dsh-running');
    item.card.removeAttribute('data-baili-dsh-waiting');
    item.card.querySelector(':scope > [data-dcs-composer-rim]')?.remove();
    if (item.card.nextElementSibling?.matches('[data-dcs-pet-stage]')) item.card.nextElementSibling.remove();
    if (!item.seat.querySelector(':scope > [data-baili-dsh-card]')) item.seat.querySelector(':scope > [data-dcs-composer-aura]')?.remove();
  }
  function sync() {
    timer = 0;
    if (disposed) return;
    const live = new Set();
    for (const composer of document.querySelectorAll(HOST)) {
      const editor = composer.querySelector(EDITOR);
      const card = editor?.closest(SURFACE);
      const seat = card?.parentElement;
      if (!seat || !card.getClientRects().length) continue;
      live.add(composer);
      let item = cards.get(composer);
      if (!item || item.card !== card || item.editor !== editor) {
        if (item) clear(item);
        const sliderMount = document.createElement('div');
        sliderMount.className = 'baili-dsh-inline-mount';
        editor.setAttribute('data-baili-dsh-editor', '');
        // Separate marker attributes avoid touching native composer slots and styles.
        card.setAttribute('data-baili-dsh-card', '');
        seat.setAttribute('data-baili-dsh-seat', '');
        item = {card, seat, editor, sliderMount, sliderRoot:createRoot(sliderMount), signature:null};
        cards.set(composer, item);
      }
      const native = config().enabled === false ? null : picker(composer);
      if (native) {
        const anchor = modelAnchor(native.button);
        if (item.sliderMount.nextElementSibling !== anchor || item.sliderMount.parentElement !== anchor.parentElement) anchor.before(item.sliderMount);
        const signature = JSON.stringify([native.current.model, native.current.id, native.options.map(option => option.reasoningEffort)]);
        if (signature !== item.signature) {
          item.signature = signature;
          item.sliderRoot.render(h(InlineEffort, {key:native.current.model, composer, native}));
        }
      } else if (item.signature !== null) {
        item.signature = null;
        item.sliderRoot.render(null);
        item.sliderMount.remove();
      }
      const running = [...composer.querySelectorAll('button[aria-label]')].some(button => STOP.test(button.getAttribute('aria-label')));
      item.card.toggleAttribute('data-baili-dsh-running', running);
      const approval = composer.closest('[data-app-shell-active-page=true]')?.querySelector('[data-codex-approval-surface]')
        ?? composer.querySelector('[data-codex-approval-surface]');
      item.card.toggleAttribute('data-baili-dsh-waiting', Boolean(approval?.getClientRects().length));
    }
    for (const [composer, item] of cards) if (!live.has(composer)) {
      clear(item);
      cards.delete(composer);
      if (active === composer) panel.close();
    }
  }
  function schedule() { if (!timer && !disposed) timer = requestAnimationFrame(sync); }
  const observer = new MutationObserver(records => {
    if (records.some(({target}) => !panel.contains(target) && !target.closest?.('[data-dcs-composer-rim], [data-dcs-pet-stage], .baili-dsh-inline-mount'))) schedule();
  });
  observer.observe(document.querySelector('#root') ?? body, {subtree:true,childList:true,attributes:true,attributeFilter:['aria-label','data-selected-reasoning-effort','data-model-selection-label','contenteditable','disabled','aria-disabled']});
  const unsubscribe = configStore.subscribe(schedule);
  function keyboard(event) {
    if (!event.repeat && event.ctrlKey && event.altKey && event.code === 'KeyG') {
      event.preventDefault();
      if (panel.open) panel.close();
      else openSettings(document.activeElement?.closest(HOST) ?? cards.keys().next().value);
    }
  }
  function dispose() {
    if (disposed) return;
    disposed = true;
    cancelAnimationFrame(timer);
    observer.disconnect();
    unsubscribe();
    unmountEffect();
    dsh.disposeAudio();
    window.removeEventListener('keydown', keyboard, true);
    window.removeEventListener('pagehide', dispose);
    panel.close();
    root.unmount();
    panel.remove();
    for (const item of cards.values()) clear(item);
    cards.clear();
    style.remove();
    delete window.__bailiDsh;
  }
  window.addEventListener('keydown', keyboard, true);
  window.addEventListener('pagehide', dispose, {once:true});
  window.__bailiDsh = {dispose, openSettings:() => openSettings(cards.keys().next().value), status:() => ({composers:cards.size, nativeSlider:!!picker(cards.keys().next().value)})};
  sync();
  return {installed:true};
}
